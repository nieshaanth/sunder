public interface performance {
	public float getAttendance();
	public float getScores();
}
