

public class Payments {
	public Object fee type;
	public void checkPayment() {
	
	}
	
	public void makePayment() {
	
	}
}
