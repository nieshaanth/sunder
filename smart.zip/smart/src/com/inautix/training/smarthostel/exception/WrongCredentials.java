package com.inautix.training.smarthostel.exception;

public class WrongCredentials extends Exception{

	public  WrongCredentials() {
		System.out.println("Invalid user id or password");
	}

}
