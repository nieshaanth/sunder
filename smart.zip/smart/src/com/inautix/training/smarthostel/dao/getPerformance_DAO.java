package com.inautix.training.smarthostel.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

import com.inautix.training.smarthostel.controller.Login;





public class getPerformance_DAO {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	
	public Login getDetails(String sessionId){
		System.out.println("inside get details");
		Login li=new Login();
		Connection con=null;
		try {
			System.out.println("inside try");
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		String sql;

		try {
			
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			sql="select * from stud_perf_201189 where register_number='"+sessionId+"'";
			
			System.out.println(sql);//System.out.println(str);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			//ResultSet rss = stmt.executeQuery(str); 
			while(rs.next()) {
			//System.out.println(rs.getLong(1)+"   "+rs.getString("userid")+" "+rs.getString("password"));
				
				li.setRegno(rs.getString("register_number"));
				li.setAttendance(rs.getFloat("att_percentage"));
				li.setScore(rs.getFloat("scores"));
			}
			
		
		}
		

		catch(Exception e){
			
			
		}
		finally{
			try{
				con.commit();
				con.close();
			}catch(Exception e){
				
			}
		}
		
		return li;

	}
	

}
