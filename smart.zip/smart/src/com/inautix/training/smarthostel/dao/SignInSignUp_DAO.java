package com.inautix.training.smarthostel.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Random;

import com.inautix.training.smarthostel.controller.Login;


public class SignInSignUp_DAO {
	Connection con=null;
	int count=0;
	public void registration(Login login){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		
		String sql ="insert into registration_201189 values ('"+login.getFname()+"','"+login.getLname()+"','"+login.getDOB()+"',"+login.getRegno()+",'"+login.getPassword()+"',"+login.getYear()+",'"+login.getDept()+"','"+login.getEmail()+"',"+login.getContact()+",'"+login.getSecQues()+"')";
		System.out.println(sql);			

		stmt.execute(sql);
		System.out.println("Customer record inserted successfully");
		
		Random r = new Random();
		double rangeMin=50.00,rangeMax=100.00;
		double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
		double scoreMin=5.0,scoreMax=9.9;
		double randomScore = scoreMin + (scoreMax - scoreMin) * r.nextDouble();

		String str="insert into stud_perf_201189 values ('"+login.getRegno()+"',"+String.format("%.3f",randomValue)+","+String.format("%.4f",randomScore)+")";
		System.out.println(str);
		stmt.execute(str);
		
		
		//double feeMin=2500.00,feeMax=3100.00;
		double randomfee =99.87;//feeMin + (feeMax - feeMin) * r.nextDouble();
		int fine=0;
		if(randomValue<80.00 && randomValue>=75.00)fine=1000;
		else if(randomValue<75.00)fine=35000;
		
		String st="insert into payment_201189 values ('"+login.getRegno()+"',"+randomfee+","+fine+")";
		System.out.println(st);
		stmt.execute(st);
		
		
		}
		catch(Exception e){
			System.out.println(e);
			
		}
		finally{
			
			try{
			con.commit();
			con.close();
			}
			catch(Exception e){
				System.out.println("Exception:"+e);
			}
		}
		
				
	}
	
	
	
	
	
	
	public boolean retrieve(Login login){
		System.out.println("inside retrieve()");
		boolean isCorrect=true;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		String str = null,sql;

		try {
			System.out.println("inside try");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			sql="select password from registration_201189 where register_number='"+login.getRegno()+"'";
			//System.out.println("retrieving data");
			System.out.println(sql);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
			//System.out.println(rs.getLong(1)+"   "+rs.getString("userid")+" "+rs.getString("password"));
				str=rs.getString("Password");
				//System.out.println("PASSWORD:"+str);
			}
			if(!login.getPassword().equals(str))isCorrect=false;
			
			
			
			//count+=1;
			double fee=99.87;
			double feeAmt=0.0;
			double d=0.0;
			String st="select att_percentage from stud_perf_201189 where register_number='"+login.getRegno()+"'";
			System.out.println(st);
			
			ResultSet rss = stmt.executeQuery(st);
			while(rss.next()){
				d=rss.getFloat("att_percentage");
			}
			System.out.println(d);

			
			//double fee=0.0;
			String select="select fee_amount from payment_201189 where register_number='"+login.getRegno()+"'";
			System.out.println(select);
			ResultSet rsss = stmt.executeQuery(select);
			while(rsss.next()){
				feeAmt=rsss.getFloat("fee_amount");
			}
			feeAmt+=fee;
			System.out.println(feeAmt);
			
			
			String s="update payment_201189 set fee_amount="+String.format("%.2f",feeAmt)+" where register_number='"+login.getRegno()+"'";
			
			System.out.println(s);
			stmt.executeUpdate(s);
		
		}
		
		

		catch(Exception e){
			
			
		}
		finally{
			try{
				con.commit();
				con.close();
			}catch(Exception e){
				
			}
		}
		return isCorrect;

	}
	
	
	
}
