package com.inautix.training.smarthostel.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.training.smarthostel.controller.Login;

public class getContact_DAO {

	public Login getDetails(String sessionId){
		System.out.println("inside retrieve()");
		@SuppressWarnings("rawtypes")
		Login li=new Login();
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		String sql;

		try {
			System.out.println("inside try");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			sql="select * from registration_201189 where register_number='"+sessionId+"'";
			//System.out.println("retrieving data");
			System.out.println(sql);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			 
			while(rs.next()) {
			//System.out.println(rs.getLong(1)+"   "+rs.getString("userid")+" "+rs.getString("password"));
				
				li.setLname(rs.getString("last_name"));
				//li.setRegno(rs.getString("register_number"));
				li.setEmail(rs.getString("email"));
				li.setContact(rs.getLong("contact"));
			}
		
		}
		

		catch(Exception e){
			
			
		}
		finally{
			try{
				con.commit();
				con.close();
			}catch(Exception e){
				
			}
		}
		
		return li;

	}

}
