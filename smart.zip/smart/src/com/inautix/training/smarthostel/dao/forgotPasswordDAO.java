package com.inautix.training.smarthostel.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.training.smarthostel.controller.Login;

public class forgotPasswordDAO {

	Connection con=null;
	public void registration(Login login){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
String sql ="update registration_201189 set password='"+login.getPassword()+"' where register_number='"+login.getRegno()+"'";
System.out.println(sql);			

stmt.execute(sql);
		System.out.println("Customer record updated successfully");
		}
		catch(Exception e){
			System.out.println(e);
			
		}
		finally{
			
			try{
			con.commit();
			con.close();
			}
			catch(Exception e){
				System.out.println("Exception:"+e);
			}
		}
		
				
	}
	public boolean retrieve(Login login){
		//System.out.println("inside retrieve()");
		boolean isCorrect=true;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		String str = null,sql;

		try {
			System.out.println("inside try");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			sql="select sec_ques from registration_201189 where register_number='"+login.getRegno()+"'";
			//System.out.println("retrieving data");
			System.out.println(sql);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
			//System.out.println(rs.getLong(1)+"   "+rs.getString("userid")+" "+rs.getString("password"));
				str=rs.getString("sec_ques");
				//System.out.println("PASSWORD:"+str);
			}
		
		}
		

		catch(Exception e){
			
			
		}
		finally{
			try{
				con.commit();
				con.close();
			}catch(Exception e){
				
			}
		}
		if(!login.getSecQues().equals(str))isCorrect=false;
		return isCorrect;

	}
}
