package com.inautix.training.smarthostel.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

import com.inautix.training.smarthostel.controller.Login;





public class getStudentCourses_DAO {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	
	public List getDetails(String sessionId){
		List list=new ArrayList();

		System.out.println("inside get details");
		Login li=new Login();
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		String sql,str;

		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			Statement stmt = con.createStatement();
			ResultSet rs ;//= stmt.executeQuery(sql);
			System.out.println("inside try");
			
			str="select department,stud_year from registration_201189 where register_number='"+sessionId+"'";
			System.out.println(str);
			ResultSet rss=stmt.executeQuery(str);
			while(rss.next()){
				li.setDept(rss.getString("department"));
				li.setYear(rss.getInt("stud_year"));
			}
			
			System.out.println(li.getDept()+""+li.getYear());
			sql="select subjects from dept_details_201189 where department='"+li.getDept()+"' and stud_year="+li.getYear();
			System.out.println(sql);//System.out.println(str);
			rs=stmt.executeQuery(sql);
			//ResultSet rss = stmt.executeQuery(str); 
			while(rs.next()) {
			
				list.add(rs.getString("subjects"));
			}
			
		
		}
		

		catch(Exception e){
			
			
		}
		finally{
			try{
				con.commit();
				con.close();
			}catch(Exception e){
				
			}
		}
		
		return list;

	}
	

}
