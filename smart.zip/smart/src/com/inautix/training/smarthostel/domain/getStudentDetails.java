package com.inautix.training.smarthostel.domain;


import java.util.*;

import com.inautix.training.smarthostel.controller.Login;

import com.inautix.training.smarthostel.dao.getDetailsDAO;

public class getStudentDetails {
		@SuppressWarnings("rawtypes")
		public Login getDetails(String sessionId){
		getDetailsDAO gd=new getDetailsDAO();
		Login li=new Login();
		li=gd.getDetails(sessionId);
		return li;
		}
	
}
