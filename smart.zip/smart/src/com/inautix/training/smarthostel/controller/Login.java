package com.inautix.training.smarthostel.controller;

public class Login {

	public String firstName;
	public String lastName;
	public String dob;
	public String password;
	public int year;
	public String dept;
	public String email;
	public String registerNumber;
	public long contact;
	public String sec_ques;
	public float score;
	public float attendance;
	public float fee;
	public int fine;
	public String[] courses=new String[10];
	
	public void setFname(String fname){
		this.firstName=fname;
	}
	public void setLname(String lname){
		this.lastName=lname;
	}
	public void setDOB(String dob){
		this.dob=dob;
	}
	public void setYear(int year){
		this.year=year;
	}
	public void setDept(String dept){
		this.dept=dept;
	}
	public void setEmail(String email){
		this.email=email;
	}	
	public void setPassword(String password){
		this.password=password;
	}
	public void setRegno(String registerNumber){
		this.registerNumber=registerNumber;
	}
	public void setContact(long contact){
		this.contact=contact;
	}
	public void setSecQues(String sec_ques){
		this.sec_ques=sec_ques;
	}
	public void setScore(float score){
		this.score=score;
	}
	public void setAttendance(float attendance){
		this.attendance=attendance;
	}	
	public void setCourses(String[] courses){
		for(int i=0;i<courses.length;i++)
			this.courses[i]=courses[i];
	}
	public void setFee(float fee){
		this.fee=fee;
	}
	public void setFine(int fine){
		this.fine=fine;
	}
	
	
	
	public String getFname(){
		return firstName;
	}
	public String getLname(){
		return lastName;
	}
	public String getDOB(){
		return dob;
	}
	public int getYear(){
		return year;
	}
	public String getDept(){
		return dept;
	}
	public String getEmail(){
		return email;
	}	
	public String getPassword(){
		return password;
	}
	public String getRegno(){
		return registerNumber;
	}
	public long getContact(){
		return contact;
	}
	public String getSecQues(){
		return sec_ques;
	}
	public float getScore(){
		return score;
	}
	public float getAttendance(){
		return attendance;
	}	
	public String[] getCourses(){
		return courses;
	}
	public float getFee(){
		return fee;
	}
	public int getFine(){
		return fine;
	}
}
