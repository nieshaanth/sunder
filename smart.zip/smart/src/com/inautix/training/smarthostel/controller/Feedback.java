package com.inautix.training.smarthostel.controller;


public class Feedback {
public String feedback;
public String complaints;
public void submit() {
	
	}
	
	public void logout() {
	
	}
}
   