package com.inautix.training.smarthostel.controller;

import com.inautix.training.smarthostel.dao.SignInSignUp_DAO;

public class ManagingStudentperformance {
	SignInSignUp_DAO db=new SignInSignUp_DAO();  

	public void registration(Login login){
		db.registration(login);
	}
	/*public String retrieve(String uid){
		//System.out.println("before retrieval");
		String s=db.retrieve(uid);
		//System.out.println("after retrieval");

		return s;
	}/*
	/*public Login getDetails(long uid){
		Login login=null;
		login=db.getDetails(uid);
		return login;
	}*/
}
