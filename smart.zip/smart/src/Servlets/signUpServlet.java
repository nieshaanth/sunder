package Servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.training.smarthostel.controller.Login;
import com.inautix.training.smarthostel.controller.ManagingStudentperformance;

/**
 * Servlet implementation class signUpServlet
 */
@WebServlet("/signUpServlet")
public class signUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public signUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				
		Login login=new Login();
		login.setFname(request.getParameter("firstname"));
		login.setLname(request.getParameter("lastname"));
		login.setDOB(request.getParameter("bday"));
		login.setRegno(request.getParameter("regno"));
		login.setPassword(request.getParameter("password"));
		int year=Integer.parseInt(request.getParameter("year"));
		login.setYear(year);
		login.setDept(request.getParameter("dept"));
		login.setEmail(request.getParameter("email"));
		long contact=Long.parseLong(request.getParameter("connumber"));
		login.setContact(contact);
		login.setSecQues(request.getParameter("seckey"));
		
		ManagingStudentperformance managingStudentperformance=new ManagingStudentperformance();
		managingStudentperformance.registration(login);
	
		System.out.println("");
		System.out.println("regsitered successfully");
		response.setContentType("text/html");
		response.sendRedirect("signIn.html");

	}

}
