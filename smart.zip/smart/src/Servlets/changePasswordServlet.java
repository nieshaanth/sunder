package Servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.smarthostel.controller.Login;
import com.inautix.training.smarthostel.dao.forgotPasswordDAO;


@WebServlet("/changePasswordServlet")
public class changePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public changePasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Login login=new Login();
		HttpSession session=request.getSession(true);
		login.setRegno((String)session.getAttribute("register_number"));
		login.setPassword(request.getParameter("password"));
		forgotPasswordDAO fpd=new forgotPasswordDAO();
		fpd.registration(login);
		response.setContentType("text/html");
		response.sendRedirect("signIn.html");
	}

}
