package Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.smarthostel.controller.Login;
import com.inautix.training.smarthostel.dao.forgotPasswordDAO;


@WebServlet("/forgotPasswordServlet")
public class forgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public forgotPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Login login=new Login();
		login.setRegno(request.getParameter("userid"));
		login.setSecQues(request.getParameter("security"));
		forgotPasswordDAO fpd=new forgotPasswordDAO();
		boolean isCorrect=fpd.retrieve(login);
		if(isCorrect){
			HttpSession session=request.getSession(true);
			session.setAttribute("userid", login.getRegno());
			//System.out.println("inside siginservlet authentiction passed "+login.getRegno());
			RequestDispatcher rd = request.getRequestDispatcher("/passwordChange.html");
			rd.forward(request, response);
			
		}else 
		{
			request.setAttribute("key", "Login failed");
			//System.out.println("Wrong credentials!!");
			RequestDispatcher rd = request.getRequestDispatcher("/forgotPassword.html");
			rd.forward(request, response);
		}
	}

}
