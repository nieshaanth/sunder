package Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.smarthostel.controller.Login;
import com.inautix.training.smarthostel.controller.ManagingStudentperformance;
import com.inautix.training.smarthostel.dao.SignInSignUp_DAO;


@WebServlet("/signinServlet")
public class signinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public signinServlet() {
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String regno=request.getParameter("userid");
		String password=request.getParameter("password");
		boolean isCorrect;
		Login login=new Login();
		login.setRegno(regno);
		login.setPassword(password);
		SignInSignUp_DAO dbm=new SignInSignUp_DAO();
		isCorrect=dbm.retrieve(login);
		if(isCorrect){
			HttpSession session=request.getSession(true);
			session.setAttribute("register_number", login.getRegno());
			//System.out.println("inside siginservlet authentiction passed "+login.getRegno());
			RequestDispatcher rd = request.getRequestDispatcher("/profile.jsp");
			rd.forward(request, response);
			
		}else 
		{
			request.setAttribute("key", "Login failed");
			System.out.println("Wrong credentials!!");
			RequestDispatcher rd = request.getRequestDispatcher("/WrongSignIn.html");
			rd.forward(request, response);
		}
	}

}
